package epamlab.constant;
public class ConstantElevator {
	public static int storiesNumber;
	public static int  elevatorCapacity;
	public static int   passengersNumber;
    public static int   animationBoost;
}
